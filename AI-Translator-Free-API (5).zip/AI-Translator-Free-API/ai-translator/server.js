
import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = express();
const port = Number(process.env.PORT || 3000);
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.use(express.json({ limit: "100kb" }));
app.use(express.static(path.join(__dirname, "public")));

const languages = new Set(["auto", "kk", "ru", "en"]);
const languageNames = {
  auto: "Авто",
  kk: "Қазақша",
  ru: "Русский",
  en: "English"
};

app.get("/api/health", (_req, res) => {
  res.json({
    ok: true,
    configured: true,
    provider: "MyMemory"
  });
});

// Делит длинный текст на небольшие части для бесплатного API.
function splitText(text, maxLength = 400) {
  const words = text.trim().split(/\s+/);
  const chunks = [];
  let current = "";

  for (const word of words) {
    if (word.length > maxLength) {
      if (current) chunks.push(current);
      current = "";
      for (let i = 0; i < word.length; i += maxLength) {
        chunks.push(word.slice(i, i + maxLength));
      }
      continue;
    }

    const next = current ? `${current} ${word}` : word;

    if (next.length > maxLength) {
      chunks.push(current);
      current = word;
    } else {
      current = next;
    }
  }

  if (current) chunks.push(current);
  return chunks;
}

async function translateChunk(text, source, target) {
  const langpair = `${source === "auto" ? "autodetect" : source}|${target}`;
  const params = new URLSearchParams({
    q: text,
    langpair
  });

  const response = await fetch(
    `https://api.mymemory.translated.net/get?${params}`,
    { signal: AbortSignal.timeout(20000) }
  );

  if (!response.ok) {
    throw new Error(`Сервис перевода ответил: ${response.status}`);
  }

  const data = await response.json();

  if (data.responseStatus !== 200 || !data.responseData?.translatedText) {
    throw new Error(
      data.responseDetails || "Не удалось получить перевод."
    );
  }

  return data.responseData.translatedText;
}

app.post("/api/translate", async (req, res) => {
  try {
    const {
      text,
      source = "auto",
      target = "ru",
      action = "translate"
    } = req.body ?? {};

    if (typeof text !== "string" || !text.trim()) {
      return res.status(400).json({
        error: "Введите текст для обработки."
      });
    }

    if (text.length > 12000) {
      return res.status(413).json({
        error: "Максимальная длина текста — 12 000 символов."
      });
    }

    if (!languages.has(source) ||
        !languages.has(target) ||
        target === "auto") {
      return res.status(400).json({
        error: "Выберите поддерживаемые языки."
      });
    }

    if (action === "improve") {
      const cleaned = text.trim()
        .replace(/[ \t]+/g, " ")
        .replace(/\s+([,.!?;:])/g, "$1")
        .replace(/([,.!?;:])([^\s\n])/g, "$1 $2");

      return res.json({
        result: cleaned,
        note: "Выполнена базовая очистка текста без генеративной AI-модели."
      });
    }

    if (action !== "translate") {
      return res.status(400).json({
        error: "Неизвестное действие."
      });
    }

    const chunks = splitText(text);

    // Не запускаем слишком много запросов одновременно.
    const translated = [];

    for (const chunk of chunks) {
      translated.push(
        await translateChunk(chunk, source, target)
      );
    }

    res.json({
      result: translated.join(" "),
      detectedSourceLanguage:
        source === "auto" ? null : source
    });

  } catch (error) {
    console.error("Translation error:", error.message);

    res.status(502).json({
      error: error.name === "TimeoutError"
        ? "Сервис перевода не ответил вовремя. Попробуйте ещё раз."
        : error.message || "Ошибка перевода. Попробуйте позже."
    });
  }
});

app.listen(port, () => {
  console.log(`AI Translator запущен: http://localhost:${port}`);
  console.log("Сервис перевода: MyMemory (без API-ключа)");
});

const $ = (selector) => document.querySelector(selector);

const sourceLang = $("#sourceLang");
const targetLang = $("#targetLang");
const sourceText = $("#sourceText");
const resultText = $("#resultText");
const translateBtn = $("#translateBtn");
const improveBtn = $("#improveBtn");
const errorBox = $("#errorBox");
const historyKey = "ai-translator-history-v1";
const languageLabels = { auto: "Авто", kk: "Қазақша", ru: "Русский", en: "English" };
let historyItems = readHistory();
let toastTimer;

function readHistory() {
  try {
    const data = JSON.parse(localStorage.getItem(historyKey) || "[]");
    return Array.isArray(data) ? data : [];
  } catch { return []; }
}
function saveHistory() {
  localStorage.setItem(historyKey, JSON.stringify(historyItems.slice(0, 60)));
  updateHistoryCount();
}
function updateHistoryCount() {
  $("#historyCount").textContent = historyItems.length;
  $("#historySummary").textContent = `${historyItems.length} ${plural(historyItems.length, "запись", "записи", "записей")}`;
}
function plural(n, one, few, many) {
  const n10 = n % 10, n100 = n % 100;
  if (n10 === 1 && n100 !== 11) return one;
  if (n10 >= 2 && n10 <= 4 && (n100 < 12 || n100 > 14)) return few;
  return many;
}
function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2600);
}
function showError(message = "") {
  errorBox.textContent = message;
  errorBox.hidden = !message;
}
function setResult(text, empty = false) {
  resultText.textContent = text;
  resultText.classList.toggle("empty", empty);
  if (empty) {
    resultText.innerHTML = 'Ваш перевод появится здесь<span class="result-cursor"></span>';
    $("#resultMeta").textContent = "ГОТОВ К ОБРАБОТКЕ";
  } else {
    $("#resultMeta").textContent = `${text.length.toLocaleString("ru-RU")} СИМВОЛОВ`;
  }
}
function selectedSource() {
  return sourceLang.value;
}
function updateCharCount() {
  $("#charCount").textContent = `${sourceText.value.length.toLocaleString("ru-RU")} / 12 000`;
}
function addHistory(item) {
  historyItems.unshift({ ...item, id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, date: new Date().toISOString() });
  historyItems = historyItems.slice(0, 60);
  saveHistory();
}
async function requestAI(action) {
  const text = sourceText.value.trim();
  if (!text) {
    showError("Сначала введите текст для обработки.");
    sourceText.focus();
    return;
  }
  showError();
  const button = action === "translate" ? translateBtn : improveBtn;
  const otherButton = action === "translate" ? improveBtn : translateBtn;
  const oldLabel = button.innerHTML;
  button.disabled = true;
  otherButton.disabled = true;
  button.innerHTML = '<span class="loading-label">AI обрабатывает…</span>';
  setResult("Анализируем контекст и подбираем формулировки…", false);
  $("#resultMeta").textContent = "ВЫПОЛНЯЕТСЯ ЗАПРОС";
  try {
    const response = await fetch("/api/translate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        text,
        source: selectedSource(),
        target: targetLang.value,
        action,
        style: $("#styleSelect").value
      })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `Ошибка запроса (${response.status}).`);
    if (!data.result) throw new Error("Сервер вернул пустой результат.");
    setResult(data.result);
    addHistory({
      action,
      source: selectedSource(),
      target: targetLang.value,
      style: $("#styleSelect").value,
      input: text,
      result: data.result
    });
    showToast(action === "translate" ? "Перевод готов" : "Текст улучшен");
  } catch (error) {
    setResult("", true);
    showError(error.message || "Не удалось связаться с сервером.");
  } finally {
    button.disabled = false;
    otherButton.disabled = false;
    button.innerHTML = oldLabel;
  }
}
function speak(text, lang) {
  if (!text.trim()) return showToast("Нет текста для озвучивания");
  if (!("speechSynthesis" in window)) return showToast("Этот браузер не поддерживает озвучивание");
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  const langMap = { kk: "kk-KZ", ru: "ru-RU", en: "en-US", auto: "ru-RU" };
  utterance.lang = langMap[lang] || "ru-RU";
  const voices = window.speechSynthesis.getVoices();
  const prefix = utterance.lang.toLowerCase();
  const voice = voices.find(v => v.lang.toLowerCase() === prefix) || voices.find(v => v.lang.toLowerCase().startsWith(prefix.split("-")[0]));
  if (voice) utterance.voice = voice;
  utterance.onerror = () => showToast("Не удалось озвучить текст. Проверьте голосовые пакеты браузера.");
  window.speechSynthesis.speak(utterance);
}
function renderHistory() {
  updateHistoryCount();
  const list = $("#historyList");
  list.replaceChildren();
  if (!historyItems.length) {
    const empty = document.createElement("div");
    empty.className = "empty-history";
    const title = document.createElement("b");
    title.textContent = "История пока пуста";
    const detail = document.createElement("span");
    detail.textContent = "Выполненные переводы появятся здесь.";
    empty.append(title, detail);
    list.append(empty);
    return;
  }
  for (const item of historyItems) {
    const card = document.createElement("article");
    card.className = "history-card";
    const head = document.createElement("div");
    head.className = "history-card-head";
    const route = document.createElement("span");
    route.className = "history-route";
    route.textContent = item.action === "improve" ? "✧ УЛУЧШЕНИЕ ТЕКСТА" : `${languageLabels[item.source] || "Авто"} → ${languageLabels[item.target] || item.target}`;
    const date = document.createElement("span");
    date.className = "history-date";
    date.textContent = new Date(item.date).toLocaleString("ru-RU");
    head.append(route, date);
    const input = document.createElement("div");
    input.className = "history-snippet";
    input.textContent = item.input;
    const output = document.createElement("div");
    output.className = "history-result";
    output.textContent = item.result;
    const actions = document.createElement("div");
    actions.className = "history-actions";
    const useBtn = document.createElement("button");
    useBtn.className = "secondary-btn";
    useBtn.textContent = "Использовать снова";
    useBtn.addEventListener("click", () => {
      sourceText.value = item.input;
      sourceLang.value = item.source === "auto" ? "auto" : item.source;
      targetLang.value = item.target === "auto" ? "ru" : item.target;
      $("#styleSelect").value = item.style || "natural";
      updateCharCount();
      setResult(item.result);
      switchView("translator");
      showToast("Запрос восстановлен");
    });
    const copyBtn = document.createElement("button");
    copyBtn.className = "secondary-btn";
    copyBtn.textContent = "Копировать";
    copyBtn.addEventListener("click", () => copyText(item.result));
    actions.append(useBtn, copyBtn);
    card.append(head, input, output, actions);
    list.append(card);
  }
}
function switchView(view) {
  const isHistory = view === "history";
  $("#translatorView").hidden = isHistory;
  $("#historyView").hidden = !isHistory;
  document.querySelectorAll(".nav-item").forEach(btn => btn.classList.toggle("active", btn.dataset.view === view));
  $("#breadcrumbPage").textContent = isHistory ? "ИСТОРИЯ" : "ПЕРЕВОДЧИК";
  if (isHistory) renderHistory();
}
async function copyText(text) {
  if (!text) return showToast("Нет результата для копирования");
  try {
    await navigator.clipboard.writeText(text);
    showToast("Скопировано в буфер обмена");
  } catch {
    const area = document.createElement("textarea");
    area.value = text;
    area.style.position = "fixed";
    area.style.opacity = "0";
    document.body.append(area);
    area.select();
    const ok = document.execCommand("copy");
    area.remove();
    showToast(ok ? "Скопировано в буфер обмена" : "Не удалось скопировать текст");
  }
}

translateBtn.addEventListener("click", () => requestAI("translate"));
improveBtn.addEventListener("click", () => requestAI("improve"));
sourceText.addEventListener("input", updateCharCount);
sourceText.addEventListener("keydown", event => {
  if ((event.ctrlKey || event.metaKey) && event.key === "Enter") requestAI("translate");
});
$("#clearBtn").addEventListener("click", () => {
  sourceText.value = "";
  updateCharCount();
  showError();
  setResult("", true);
  sourceText.focus();
});
$("#copyBtn").addEventListener("click", () => copyText(resultText.classList.contains("empty") ? "" : resultText.textContent));
$("#speakSource").addEventListener("click", () => speak(sourceText.value, selectedSource()));
$("#speakResult").addEventListener("click", () => speak(resultText.classList.contains("empty") ? "" : resultText.textContent, targetLang.value));
$("#swapBtn").addEventListener("click", () => {
  if (sourceLang.value === "auto") {
    showToast("Сначала выберите исходный язык вместо автоопределения");
    return;
  }
  const oldSource = sourceLang.value;
  sourceLang.value = targetLang.value;
  targetLang.value = oldSource;
  const oldText = sourceText.value;
  const currentResult = resultText.classList.contains("empty") ? "" : resultText.textContent;
  if (currentResult) {
    sourceText.value = currentResult;
    setResult(oldText || "Ваш перевод появится здесь", !oldText);
    updateCharCount();
  }
});
$("#clearHistoryBtn").addEventListener("click", () => {
  if (!historyItems.length) return showToast("История уже пуста");
  if (!confirm("Удалить всю историю переводов?")) return;
  historyItems = [];
  saveHistory();
  renderHistory();
  showToast("История очищена");
});
document.querySelectorAll(".nav-item").forEach(btn => btn.addEventListener("click", () => switchView(btn.dataset.view)));

async function checkAPI() {
  try {
    const response = await fetch("/api/health");
    const data = await response.json();
    $("#apiStatus").textContent = data.configured ? "Подключение настроено" : "Нужен API-ключ";
    $("#apiStatus").previousElementSibling.style.background = data.configured ? "var(--cyan)" : "#f6b85c";
  } catch {
    $("#apiStatus").textContent = "Сервер недоступен";
    $("#apiStatus").previousElementSibling.style.background = "#ff728c";
  }
}
updateCharCount();
updateHistoryCount();
checkAPI();
